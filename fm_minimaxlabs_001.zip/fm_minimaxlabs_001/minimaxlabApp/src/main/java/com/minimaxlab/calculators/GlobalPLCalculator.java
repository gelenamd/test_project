package com.minimaxlab.calculators;

import com.minimaxlab.domain.impl.Vessel;

import java.math.BigDecimal;
import java.util.List;

public interface GlobalPLCalculator {
    //BigDecimal getPL();
    BigDecimal getPL(List<Vessel> vessels );
}

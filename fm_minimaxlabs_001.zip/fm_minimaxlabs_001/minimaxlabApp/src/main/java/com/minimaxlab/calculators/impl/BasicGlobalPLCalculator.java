package com.minimaxlab.calculators.impl;

import com.minimaxlab.calculators.GlobalPLCalculator;
import com.minimaxlab.domain.Cargo;
import com.minimaxlab.domain.impl.Port;
import com.minimaxlab.domain.impl.Vessel;
import com.minimaxlab.externalAPI.IShippingCalculator;
import com.minimaxlab.externalAPI.IShippingSchedule;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang3.Validate;

public class BasicGlobalPLCalculator implements GlobalPLCalculator {
    private IShippingSchedule shippingSchedule;
    private IShippingCalculator shippingCalculator;

    public static BasicGlobalPLCalculator create(IShippingCalculator shippingCalculator,IShippingSchedule shippingSchedule){
        Validate.notNull(shippingCalculator);
        Validate.notNull(shippingSchedule);
        return new BasicGlobalPLCalculator(shippingSchedule,shippingCalculator);
    }

    private BasicGlobalPLCalculator(IShippingSchedule shippingSchedule,IShippingCalculator shippingCalculator){
        this.shippingSchedule = shippingSchedule;
        this.shippingCalculator = shippingCalculator;
    }

    @Override
    public BigDecimal getPL(List<Vessel>vessels ){
        Validate.notNull(vessels);
        return getPLInternally(vessels);
    }

    private BigDecimal getPLInternally(List<Vessel> vessels){
        BigDecimal pl=new BigDecimal(0);
        for (Vessel vessel: vessels){
            pl = pl.add(getPLForVessel(vessel));
        }
        return pl;
    }

    private BigDecimal getPLForVessel(Vessel vessel){
        BigDecimal pl = new BigDecimal(0);
        List<Cargo> cargoes = shippingSchedule.getCargoes(vessel);
        for(Cargo cargo: cargoes){
            pl = pl.add(getPLForCargo(cargo,vessel));
        }
        return pl;
    }

    //P&L ($) = Σ(Sales Revenue - Purchase Cost - Shipping Cost)
    private BigDecimal getPLForCargo(Cargo cargo, Vessel vessel){
        BigDecimal pl = new BigDecimal(0);
        BigDecimal salesRevenue = getSalesRevenue(cargo);
        BigDecimal purchaseCost = getPurchaseCost(cargo);
        BigDecimal shippingCost = getShippingCost(cargo,vessel);
        pl = pl.add(salesRevenue);
        pl = pl.subtract(purchaseCost);
        pl = pl.subtract(shippingCost);
        return pl;
    }

    private BigDecimal getShippingCost(Cargo cargo, Vessel vessel) {
        //BigDecimal shippingCost = new BigDecimal(0);
        Port sourcePort = cargo.getLoadOpportunity().getDestination();
        Port targetPort = cargo.getDischargeOpportunity().getDestination();
        int shippingCost = shippingCalculator.getShippingCosts(sourcePort,targetPort,vessel);
        return new BigDecimal(shippingCost);
    }

    private BigDecimal getPurchaseCost(Cargo cargo) {
        return cargo.getLoadOpportunity().getContract().getPrice();
    }

    private BigDecimal getSalesRevenue(Cargo cargo) {
        return cargo.getDischargeOpportunity().getContract().getPrice();
    }
}

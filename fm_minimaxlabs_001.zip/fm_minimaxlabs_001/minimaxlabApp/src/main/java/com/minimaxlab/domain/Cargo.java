package com.minimaxlab.domain;

/**
 * Cargo interface.
 * Cargo only makes sense to exist when it allows to be
 * bought/loaded
 * sold/discharged.
 * Model is based around the Cargo.
 * Without Cargo there is no sense for model to exist.
*/
public interface Cargo {

    long getId();
    /**
     * Gives the buy/load opportunity
     * @return Opportunity
     */
    Opportunity getLoadOpportunity();

    /**
     * Gives the sale/discharge opportunity
     * @return Opportunity
     */
    Opportunity getDischargeOpportunity();
}

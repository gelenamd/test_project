package com.minimaxlab.domain;

import com.minimaxlab.domain.impl.CalorificValue;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
* Contract interface.
 * Defines the opportunities' contract.
* Assumed to have some unique id (or combination)
* Has price for the completed contract
* Contains data on volume of the LNG in cubic meters.
* Delivery/completion date
* Calorific value in mmBTU/m^3. mmBTU = 1'030'000 Joules.
* Terms (possibly four scenarios:
 * 1. bought FOB at load
 * 2. sold FOB at load
 * 3. sold DES at discharge
 * 4. bought DES at discharge)
* */
public interface Contract {
    // Assume id should exist
    long getId();
    //price for contract
    BigDecimal getPrice();
    // volume of LNG m^3
    int getVolume();
    // delivery by date
    Date getDate();
    // calorific value mmBTU/m^3
    CalorificValue getCalorificValue();
    // some terms. can be used for stage 2
    List<Term> getTerms();
}

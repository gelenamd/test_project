package com.minimaxlab.domain;

import com.minimaxlab.domain.impl.Port;
import com.minimaxlab.enums.OpportunityType;

/**
* Interface for buy-sell opportunity.
* For load opportunity - destination port is the place to load.
* For discharge opportunity - destination port is the place to unload.
* */
public interface Opportunity {
    //Some internal id UUID or other.
    long getId();
    // Some external (composite) id.
    String getExternalId();
    // Opportunity type Buy(1), Sell(2)
    OpportunityType getType();
    //Destination port.
    Port getDestination();
    //contract for the opportunity.
    Contract getContract();
}

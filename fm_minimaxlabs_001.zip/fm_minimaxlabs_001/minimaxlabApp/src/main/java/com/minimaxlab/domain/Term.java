package com.minimaxlab.domain;

/**
*Some extendable terms.
* */
public interface Term {
    // Probably the four item enumeration can be used.
}

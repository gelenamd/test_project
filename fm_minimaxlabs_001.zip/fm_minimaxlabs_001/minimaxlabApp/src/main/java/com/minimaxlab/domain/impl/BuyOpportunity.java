package com.minimaxlab.domain.impl;

import com.minimaxlab.domain.Contract;
import com.minimaxlab.enums.OpportunityType;

public class BuyOpportunity extends Opportunity {
    private BuyOpportunity(long id, String externalId, Port destination, Contract contract) {
        super(id, externalId, OpportunityType.Buy, destination, contract);
    }

    public static BuyOpportunity create(long id, String externalId, Port destination, Contract contract){
        return new BuyOpportunity(id, externalId, destination, contract);
    }
}

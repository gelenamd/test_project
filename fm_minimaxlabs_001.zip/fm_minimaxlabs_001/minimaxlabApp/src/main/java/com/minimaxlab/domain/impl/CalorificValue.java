package com.minimaxlab.domain.impl;

public class CalorificValue {
    private double value;

    public CalorificValue(double value){
        this.value = value;
    }

    public double getValue(){
        return value;
    }
}

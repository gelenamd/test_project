package com.minimaxlab.domain.impl;

import com.minimaxlab.domain.Opportunity;
import org.apache.commons.lang3.Validate;

public class Cargo implements com.minimaxlab.domain.Cargo {

    private long id;
    private Opportunity loadOpportunity;
    private Opportunity dischargeOpportunity;

    @Override
    public Opportunity getLoadOpportunity(){
        return loadOpportunity;
    }

    @Override
    public Opportunity getDischargeOpportunity(){
        return dischargeOpportunity;
    }

    public static Cargo create(long id,
                               Opportunity loadOpportunity,
                               Opportunity dischargeOpportunity){
        return new Cargo(id, loadOpportunity,dischargeOpportunity);
    }

    private Cargo(long id, Opportunity loadOpportunity, Opportunity dischargeOpportunity){
        Validate.notNull(loadOpportunity);
        Validate.notNull(dischargeOpportunity);

        this.id = id;
        this.loadOpportunity = loadOpportunity;
        this.dischargeOpportunity = dischargeOpportunity;
    }

    @Override
    public long getId() {
        return id;
    }

}

package com.minimaxlab.domain.impl;

import org.apache.commons.lang3.Validate;

public class Country {
    private int id;
    private String name;
    private String countryCode;

    public Country(int id, String name, String countryCode) {
        Validate.notNull(name);
        Validate.notNull(countryCode);

        this.id = id;
        this.name = name;
        this.countryCode = countryCode;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCountryCode() {
        return countryCode;
    }
}

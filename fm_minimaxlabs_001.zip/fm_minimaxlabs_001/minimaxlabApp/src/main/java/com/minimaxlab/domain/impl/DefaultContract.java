package com.minimaxlab.domain.impl;

import com.minimaxlab.domain.Contract;
import com.minimaxlab.domain.Term;
import com.minimaxlab.externalAPI.IPriceCurve;
import org.apache.commons.lang3.Validate;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class DefaultContract implements Contract {
    private long id;
    private IPriceCurve priceCurve;
    private int volume;
    private Date date;
    private BigDecimal constA;
    private BigDecimal constB;
    private List<Term> terms;
    private CalorificValue calorificValue;

    private DefaultContract(long id,
                           Date date,
                           int volume,
                           List<Term> terms,
                           CalorificValue calorificValue,
                           IPriceCurve priceCurve,
                           BigDecimal constA,
                           BigDecimal constB){
        Validate.notNull(priceCurve);
        Validate.notNull(constA);
        Validate.notNull(constB);
        Validate.notNull(terms);
        Validate.notNull(calorificValue);
        Validate.notNull(date);

        this.id = id;
        this.volume = volume;
        this.date = date;
        this.priceCurve = priceCurve;
        this.constA = constA;
        this.constB = constB;
    }

    public static DefaultContract create(long id,
                                         Date date,
                                         int volume,
                                         List<Term> terms,
                                         CalorificValue calorificValue,
                                         IPriceCurve priceCurve,
                                         BigDecimal constA,
                                         BigDecimal constB){
        return new DefaultContract(id, date, volume, terms, calorificValue, priceCurve, constA, constB);
    }

    @Override
    public long getId() {
        return this.id;
    }

    @Override
    public BigDecimal getPrice() {
        //default contract pricing aX+b
        BigDecimal currentPrice = new BigDecimal(priceCurve.getPrice(date));
        return constA.multiply(currentPrice).add(constB);
    }

    protected BigDecimal getPriceInternally(BigDecimal currentPrice) {
        // just in case
        return constA.multiply(currentPrice).add(constB);
    }

    @Override
    public int getVolume() {
        return this.volume;
    }

    @Override
    public Date getDate() {
        return date;
    }

    @Override
    public CalorificValue getCalorificValue() {
        return calorificValue;
    }

    @Override
    public List<Term> getTerms() {
        return terms;
    }
}

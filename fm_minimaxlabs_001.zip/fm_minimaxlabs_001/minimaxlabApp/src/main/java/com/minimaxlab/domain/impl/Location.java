package com.minimaxlab.domain.impl;

import org.apache.commons.lang3.Validate;

public class Location {
    private Country country;
    private Coordinates coordinates;

    public Location(Country country, Coordinates coordinates) {
        Validate.notNull(country);
        Validate.notNull(coordinates);

        this.country = country;
        this.coordinates = coordinates;
    }

    public Country getCountry() {
        return country;
    }

    public Coordinates getCoordinates() {
        return coordinates;
    }
}

package com.minimaxlab.domain.impl;

import com.minimaxlab.domain.Contract;
import com.minimaxlab.enums.OpportunityType;
import org.apache.commons.lang3.Validate;

public class Opportunity implements com.minimaxlab.domain.Opportunity {
    private long id;
    private String externalId;
    private OpportunityType opportunityType;
    private Port destination;
    private Contract contract;

    protected Opportunity(long id, String externalId, OpportunityType opportunityType, Port destination, Contract contract) {
        Validate.notNull(externalId);
        Validate.notNull(destination);
        Validate.notNull(contract);

        this.id = id;
        this.externalId = externalId;
        this.opportunityType = opportunityType;
        this.destination = destination;
        this.contract = contract;
    }

    @Override
    public long getId() {
        return this.id;
    }

    @Override
    public String getExternalId() {
        return this.externalId;
    }

    @Override
    public OpportunityType getType() {
        return this.opportunityType;
    }

    @Override
    public Port getDestination() {
        return this.destination;
    }

    @Override
    public Contract getContract() {
        return this.contract;
    }
}

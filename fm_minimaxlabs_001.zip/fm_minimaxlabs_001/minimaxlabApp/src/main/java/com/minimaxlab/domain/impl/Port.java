package com.minimaxlab.domain.impl;

import org.apache.commons.lang3.Validate;

public class Port {
    private long id;
    private String name;
    private Location location;

    public static Port create(long id, String name, Location location){
        Validate.notNull(name);
        Validate.notNull(location);

        return new Port(id, name, location);
    }

    private Port(long id, String name, Location location){
        this.id = id;
        this.name = name;
        this.location = location;
    }

    public long getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public Location getLocation(){
        return location;
    }
}

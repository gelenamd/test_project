package com.minimaxlab.domain.impl;

import com.minimaxlab.domain.Contract;
import com.minimaxlab.enums.OpportunityType;

public class SellOpportunity extends Opportunity {
    private SellOpportunity(long id, String externalId, Port destination, Contract contract) {
        super(id, externalId, OpportunityType.Sell, destination, contract);
    }

    public static SellOpportunity create(long id, String externalId, Port destination, Contract contract){
        return new SellOpportunity(id, externalId, destination, contract);
    }
}

package com.minimaxlab.domain.impl;

public class Vessel {
    private long id;
    private String name;

    //required for ext
    private double speed;
    private int volume;

    /*public static Vessel(long id, String name, double speed, int volume){

    }*/

    public long getId(){
        return id;
    }

    public String getName(){
        return name;
    }

    public double getSpeed(){
        return speed;
    }

    public int getVolume(){
        return volume;
    }
}

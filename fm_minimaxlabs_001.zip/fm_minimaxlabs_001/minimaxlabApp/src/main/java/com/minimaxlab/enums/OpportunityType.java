package com.minimaxlab.enums;

import com.minimaxlab.exceptions.UnknownOpportunityTypeException;

// Type of the Opportunity.
// Self explanatory at this stage.
public enum OpportunityType {

    Buy(1),
    Sell(2);

    OpportunityType(int type){
        this.type = type;
    }

    private int type;

    @Override
    public String toString(){
        switch (this.type){
            case 1:
                return "Buy";
            case 2:
                return "Sell";
                default:
                    return ("Unknown opportunity type: "+type);
                    // don't want to define the exception class
                    //throw new UnknownOpportunityTypeException("Unknown opportunity type: "+type);
        }
    }
}

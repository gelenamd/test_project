package com.minimaxlab.enums;

/**
 * Option for the contract
 * * Terms (possibly four scenarios:
 *  * 1. bought FOB at load
 *  * 2. sold FOB at load
 * 3. sold DES at discharge
 * 4. bought DES at discharge).
 */
public enum TermOption {
    BuyFOB(1),
    SellFOB(2),
    BuyDES(3),
    SellDES(4);

    private int option;

    TermOption(int option) {
        this.option = option;
    }

    public int getOption() {
        return option;
    }

    @Override
    public String toString(){
        switch (this.option){
            case 1:
                return "Buy FOB at load";
            case 2:
                return "Sell FOB at load";
            case 3:
                return "Buy DES at discharge";
            case 4:
                return "Sell DES at discharge";
            default:
                return ("Unknown opportunity type: "+this.option);
        }
    }
}

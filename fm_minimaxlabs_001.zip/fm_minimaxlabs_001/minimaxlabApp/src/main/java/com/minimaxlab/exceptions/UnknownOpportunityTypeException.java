package com.minimaxlab.exceptions;

/*
* Should add our own exception.
* */
public class UnknownOpportunityTypeException extends Exception{
    public UnknownOpportunityTypeException(String message){
        super(message);
    }
}

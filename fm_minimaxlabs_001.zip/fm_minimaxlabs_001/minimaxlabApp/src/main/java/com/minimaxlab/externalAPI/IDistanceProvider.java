package com.minimaxlab.externalAPI;

import com.minimaxlab.domain.impl.Port;

public interface IDistanceProvider {
    int getDistance(Port from, Port to);
}

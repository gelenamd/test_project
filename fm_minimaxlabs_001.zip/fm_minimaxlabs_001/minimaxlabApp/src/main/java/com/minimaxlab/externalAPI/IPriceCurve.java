package com.minimaxlab.externalAPI;
import java.util.Date;

public interface IPriceCurve {
    double getPrice(Date date);
}

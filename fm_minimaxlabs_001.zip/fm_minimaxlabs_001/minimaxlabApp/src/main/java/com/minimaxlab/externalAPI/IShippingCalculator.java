package com.minimaxlab.externalAPI;

import com.minimaxlab.domain.impl.Port;
import com.minimaxlab.domain.impl.Vessel;

public interface IShippingCalculator {
    int getShippingCosts(Port from, Port to, Vessel vessel);
}

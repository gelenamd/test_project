package com.minimaxlab.externalAPI;

import com.minimaxlab.domain.Cargo;
import com.minimaxlab.domain.impl.Vessel;

import java.util.List;

public interface IShippingSchedule {
    List<Cargo> getCargoes(Vessel vessel);
}

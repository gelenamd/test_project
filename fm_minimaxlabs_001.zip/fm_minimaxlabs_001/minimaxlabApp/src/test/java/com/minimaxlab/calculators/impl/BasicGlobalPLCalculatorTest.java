package com.minimaxlab.calculators.impl;

import static org.easymock.EasyMock.*;
import static org.junit.jupiter.api.Assertions.*;

import com.minimaxlab.calculators.GlobalPLCalculator;
import com.minimaxlab.domain.Cargo;
import com.minimaxlab.domain.Contract;
import com.minimaxlab.domain.Opportunity;
import com.minimaxlab.domain.impl.Port;
import com.minimaxlab.domain.impl.Vessel;
import com.minimaxlab.externalAPI.IShippingCalculator;
import com.minimaxlab.externalAPI.IShippingSchedule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

class BasicGlobalPLCalculatorTest {

    private static BasicGlobalPLCalculator globalPLCalculator;

    @BeforeAll
    private static void init() {
        List<Cargo> cargoes = new ArrayList<>();

        Cargo cargo = createMock(Cargo.class);
        Port port = createMock(Port.class);
        Contract loadContract = createMock(Contract.class);
        Contract dischargeContract = createMock(Contract.class);
        Opportunity loadOpportunity = createMock(Opportunity.class);
        Opportunity dischargeOpportunity = createMock(Opportunity.class);
        IShippingCalculator shippingCalculator = createMock(IShippingCalculator.class);
        IShippingSchedule shippingSchedule = createMock(IShippingSchedule.class);

        cargoes.add(cargo);
        expect(shippingCalculator.getShippingCosts(
                anyObject(Port.class),
                anyObject(Port.class),
                anyObject(Vessel.class)))
                .andReturn(100)
                .anyTimes();

        expect(shippingSchedule.getCargoes(anyObject(Vessel.class)))
                .andReturn(cargoes)
                .anyTimes();

        expect(cargo.getDischargeOpportunity())
                .andReturn(dischargeOpportunity)
                .anyTimes();
        expect(cargo.getLoadOpportunity())
                .andReturn(loadOpportunity)
                .anyTimes();

        expect(loadOpportunity
                .getContract())
                .andReturn(loadContract)
                .anyTimes();
        expect(loadOpportunity
                .getDestination())
                .andReturn(port)
                .anyTimes();

        expect(dischargeOpportunity
                .getContract())
                .andReturn(dischargeContract)
                .anyTimes();

        expect(dischargeOpportunity
                .getDestination())
                .andReturn(port)
                .anyTimes();

        expect(loadContract.getPrice())
                .andReturn(new BigDecimal(500))
                .anyTimes();
        expect(dischargeContract.getPrice())
                .andReturn(new BigDecimal(700))
                .anyTimes();

        replay(shippingCalculator);
        replay(shippingSchedule);
        replay(cargo);
        replay(loadOpportunity);
        replay(dischargeOpportunity);
        replay(loadContract);
        replay(dischargeContract);

        globalPLCalculator = BasicGlobalPLCalculator.create(shippingCalculator, shippingSchedule);
    }


    @Test
    void verify_CreateThrowsNullPointerException_WhenShippingCalculatorIsNull(){
        IShippingSchedule shippingSchedule = createMock(IShippingSchedule.class);

        Assertions.assertThrows(NullPointerException.class,()-> BasicGlobalPLCalculator.create(null,shippingSchedule));
    }

    @Test
    void verify_CreateThrowsNullPointerException_WhenShippingScheduleIsNull(){
        IShippingCalculator shippingCalculator = createMock(IShippingCalculator.class);

        Assertions.assertThrows(NullPointerException.class,()-> BasicGlobalPLCalculator.create(shippingCalculator,null));
    }

    @Test
    void verify_GetPL_ReturnsCorrectValue_ForSingleVessel() {
        BigDecimal expectedPL = new BigDecimal(100);
        List<Vessel> vessels = new ArrayList<>();
        Vessel vessel = mock(Vessel.class);
        vessels.add(vessel);

        BigDecimal pl = globalPLCalculator.getPL(vessels);

        Assertions.assertEquals(expectedPL,pl);
    }

    @Test
    void verify_GetPL_ThrowsNullPointerException_WhenCollectionOfVesselsIsNull(){
        Assertions.assertThrows(NullPointerException.class,()-> globalPLCalculator.getPL(null));
    }

    @Test
    void verify_GetPL_ReturnsCorrectValue_ForMultipleVessels(){
        BigDecimal expectedPL = new BigDecimal(200);
        List<Vessel> vessels = new ArrayList<>();
        Vessel vessel = mock(Vessel.class);
        vessels.add(vessel);
        Vessel vessel2 = mock(Vessel.class);
        vessels.add(vessel2);

        BigDecimal pl = globalPLCalculator.getPL(vessels);

        Assertions.assertEquals(expectedPL,pl);
    }
}
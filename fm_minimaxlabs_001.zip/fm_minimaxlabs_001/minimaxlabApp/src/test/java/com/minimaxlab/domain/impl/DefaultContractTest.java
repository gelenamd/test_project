package com.minimaxlab.domain.impl;

import com.minimaxlab.domain.Contract;
import com.minimaxlab.domain.Term;
import com.minimaxlab.externalAPI.IPriceCurve;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.easymock.EasyMock.*;
import static org.junit.jupiter.api.Assertions.*;

class DefaultContractTest {

    @Test
    void verify_CreateThrowsNullPointerException_WhenDateIsNull() {
        IPriceCurve priceCurve = createMock(IPriceCurve.class);
        assertThrows(NullPointerException.class,()->DefaultContract.create(1,
                null,
                100,
                new ArrayList<>(),
                new CalorificValue(1000.0),
                priceCurve,
                new BigDecimal(4),
                new BigDecimal(20) ));
    }

    @Test
    void verify_CreateThrowsNullPointerException_WhenTermsAreEmpty() {
        IPriceCurve priceCurve = createMock(IPriceCurve.class);
        assertThrows(NullPointerException.class,()->DefaultContract.create(1,
                new Date(),
                100,
                null,
                new CalorificValue(1000.0),
                priceCurve,
                new BigDecimal(4),
                new BigDecimal(20) ));
    }

    @Test
    void verify_CreateThrowsNullPointerException_WhenPriceCurveIsNull() {
        assertThrows(NullPointerException.class,()->DefaultContract.create(1,
                new Date(),
                100,
                new ArrayList<>(),
                new CalorificValue(1000.0),
                null,
                new BigDecimal(4),
                new BigDecimal(20) ));
    }


    @Test
    void verify_CreateThrowsNullPointerException_WhenCalorificValueIsEmpty() {
        IPriceCurve priceCurve = createMock(IPriceCurve.class);
        assertThrows(NullPointerException.class,()->DefaultContract.create(1,
                new Date(),
                100,
                new ArrayList<>(),
                null,
                priceCurve,
                new BigDecimal(4),
                new BigDecimal(20) ));
    }

    @Test
    void verify_CreateThrowsNullPointerException_WhenConstAIsEmpty() {
        IPriceCurve priceCurve = createMock(IPriceCurve.class);
        assertThrows(NullPointerException.class,()->DefaultContract.create(1,
                new Date(),
                100,
                new ArrayList<>(),
                new CalorificValue(1000.0),
                priceCurve,
                null,
                new BigDecimal(20) ));
    }

    @Test
    void verify_CreateThrowsNullPointerException_WhenConstBIsEmpty() {
        IPriceCurve priceCurve = createMock(IPriceCurve.class);
        assertThrows(NullPointerException.class,()->DefaultContract.create(1,
                new Date(),
                100,
                new ArrayList<>(),
                new CalorificValue(1000.0),
                priceCurve,
                new BigDecimal(4),
                null ));
    }

    @Test
    void verify_GetPrice_ReturnsCorrectValue_ForSetConstAConstBAndPriceCurve() {
        BigDecimal expectedPrice = new BigDecimal(100);
        BigDecimal constA = new BigDecimal(4);
        BigDecimal constB = new BigDecimal(20);
        IPriceCurve priceCurve = createMock(IPriceCurve.class);

        expect(priceCurve.getPrice(anyObject(Date.class))).andReturn(20.0);

        replay(priceCurve);

        Contract defaultContract = DefaultContract.create(1,
                new Date(),
                100,
                new ArrayList<>(),
                new CalorificValue(1000.0),
                priceCurve,
                constA,
                constB);

        BigDecimal actualPrice = defaultContract.getPrice();

        assertEquals(expectedPrice, actualPrice);
    }
}